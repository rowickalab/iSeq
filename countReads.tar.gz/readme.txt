To run it, type 'perl countReads'

This script counts the number of reads in a specific region (eg. G-quadruplex) included in a bed file (3 columns: chr start end).
The sequencing depth for each position on the genome is saved in a wig file (4 colums: chr start end depth).

Usage: perl countReads <bed_file> <wig_file> [options]

    -d CHARACTER        output directory
    -p CHARACTER        output prefix
    -l NUMERIC          extend from left position to the left
    -r NUMERIC          extend from right position to the right
    -center             if defined: take center of two postions in bed file,
                        if not: take two positions in bed file
    -checkovl           if defined: check overlap, and redefine region from the middle of overlapped regions
                        if not: don't check overlap, use left and right poistions
Output:
1) .txt record the number of reads in each region
2) .stat        a brief statistics
3) .pos record the details of reads in each region and position
4) .mat record the details of reads in each region and position by matrix
