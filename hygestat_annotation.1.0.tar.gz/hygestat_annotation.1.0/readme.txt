This software is part of iSeq (breakome.eu)
Hygestat_annotation Version 1.0.
Hygestat-annotation compares BLESS-enriched genome areas with genome annotation data.
Program input consists of the following files:
1. hygestat_bless output (or any datafile in compatible format, recording some genomic 
characteristic binned into homogenous genome windows),
2. annotation file in BED or bedGraph format, recording arbitrary discrete or continuous 
genomic feature, respectively,
3. (optionally) genome mappability data, imported to bitarray format.

Hygestat-annotation calculates the overlap between BLESS-significant windows and featured 
genome areas (in the case of discrete annotation data) or the average feature level in 
BLESS-significant windows (in the case of continuous annotation data).
In both cases, the result is compared to the expected value for randomly selected windows
and p-values for enrichment and depletion are calculated.
When the mappability data are provided, the analysis is restricted to mappable genome areas.


REQUIREMENTS

Hygestat_annotation is fully written in Python. 
It requires Python 2.7 with package bitarray 0.8.1 installed. 
See https://pypi.python.org/pypi/bitarray for bitarray installation options.

Usage: hygestat_annotation.py [options]


OPTIONS

  -h, --help            show this help message and exit
  -F FFILE, --feature-file=FFILE
                        path to the annotation data file
  -B BFILE, --bless-file=BFILE
                        path to the bless data file
  -f FNAME, --feature-name=FNAME
                        annotation name for output data (path to the
                        annotation data file by default)
  -b BNAME, --bless-name=BNAME
                        BLESS experiment name for output data (path to the
                        bless data file by default)
  -g, --bedgraph        annotation data in bedGraph format (BED format by
                        default)
  -O OUTFILE, --output-file=OUTFILE
                        path to the output file
  -a, --append-output   append output to existing file (create a new file by
                        default)
  -p PVTHRS, --pvalue-thresholds=PVTHRS
                        comma separated list of p-value thresholds for BLESS
                        data (0.05 by default)
  -c PVCOL, --pvalue-column=PVCOL
                        p-value column in bless data file (7 by default)
  -M MAPDIR, --mappability-dir=MAPDIR
                        path to the mappability data directory (no mappability 
                        by default)
  -n NTEST, --n-tests=NTEST
                        number of permutation tests (1000 by default)

ARGUMENT DETAILS

  FFILE - annotation data in BED or bedGraph format to be compared with BLESS data.
        All but the first 3 (BED) or 4 (bedGraph) fields in each line are ignored.
  BFILE - BLESS data output from hygestat_bless.
  FNAME and BNAME - input data names used in the output file (see OUTPUT FORMAT below).
  OUTFILE - output is written as a tab-separated text file (see OUTPUT FORMAT below).
  PVTHRS - significance level thresholds for BLESS data.
  PVCOL - column determining p-value type for BLESS data; possible values are:
        6 - p-value from the hypergeometric test,
        7 - Benjamini-Hochberg corrected hypergeometric p-value (default),
        8 - Bonferroni corrected hypergeometric p-value.
  MAPDIR - directory with the mappability data imported to binary format (see MAPPABILITY 
        below);
  NTEST - the number of permutations in the enrichment/depletion estimation;
        resulting p-value resolution equals 1/NTEST.


OUTPUT FORMAT

Each row in the output file contains the following fields:
  feature - FNAME argument
  treatment - BNAME argument
  pv_threshold - BLESS p-value threshold, a component of PVTHRS argument
  level_all - the proportion of nucleotides covered by features in the whole genome
  level_fragile - the proportion of nucleotides covered by features
        in BLESS-significant windows (i.e. with window p-value <= pv_threshold)
  level_proportion - level_fragile/level_all ratio
  pval_enrichment - p-value for the level_proportion enrichment
  pval_depletion - p-value for the level_proportion depletion


MAPPABILITY

When option -M is specified, statistics are calculated with respect to mappable nucleotides.
Pre-computed mappability data for several organisms are available in text format on the BLESS website. 
In order to accelerate data loading, hygestat-annotation uses more compact binary format.
Script import_mappability converts the mappability data from text to binary format.

Usage: import_mappability.py INPUT_DIRECTORY OUTPUT_DIRECTORY

Argument details:
  INPUT_DIRECTORY - path to the directory with mappability data in hygestat_bless format
  OUTPUT_DIRECTORY - path to the directory for mappability data in hygestat_annotation format;
        if the directory does not exists, it will be created.


