#!/usr/bin/python
#This software is part of iSeq suite of software (breakome.eu)
#Hygestat_annotation Version 1.0
from sys import argv
from os import mkdir
from bitarray import bitarray

inprefix=argv[1]
outprefix=argv[2]
if inprefix[-1]!='/':
    inprefix+='/'
if outprefix[-1]!='/':
    outprefix+='/'

in_chroms_file_name="fragfiles.txt"
out_chroms_file_name='chroms.len'
    
def toba(chr0_name,inprefix,outprefix):
    in_file_name =inprefix+'map_'+chr0_name+'.txt'
    fin=open(in_file_name)
    ba=bitarray()
    for line in fin:
        ln=line.strip()
        if ln:
            ba.append(ln=='1')
    fin.close()
    
    if chr0_name[3]=='0':
        chr_name=chr0_name[:3]+chr0_name[4:-3]
    else:
        chr_name=chr0_name[:-3]
    out_file_name=outprefix+chr_name+'.ba'
    fout=open(out_file_name,'wb')
    ba.tofile(fout)
    fout.close()
    return chr_name, ba.length()
    

fin=open(inprefix+in_chroms_file_name)
chroms_files=fin.read().split()
fin.close()

try:
    mkdir(outprefix)
except OSError:
    pass
foout=open(outprefix+out_chroms_file_name,'w')
for chr0_name in chroms_files:
    foout.write('{}\t{}\n'.format(*toba(chr0_name,inprefix,outprefix)))
foout.close()
