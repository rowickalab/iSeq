#!/usr/bin/python
#Hygestat_annotation Version 1.0
from bisect import bisect_left, bisect_right
from random import shuffle
from bitarray import bitarray
from itertools import izip
from optparse import OptionParser

parser = OptionParser()
parser.add_option("-F", "--feature-file", dest="ffile", 
                  help="path to the annotation data file")
parser.add_option("-B", "--bless-file", dest="bfile", 
                  help="path to the bless data file")
parser.add_option("-f", "--feature-name", dest="fname", default=None,
                  help="annotation name for output data (path to the annotation data file by default)")
parser.add_option("-b", "--bless-name", dest="bname", default=None,
                  help="BLESS experiment name for output data (path to the bless data file by default)")
parser.add_option("-g", "--bedgraph", dest="bg", action="store_true", default=False, 
                  help="annotation data in bedGraph format (BED format by default)")
parser.add_option("-O", "--output-file", dest="outfile", help="path to the output file")
parser.add_option("-a", "--append-output", dest="apnd", action="store_true", default=False, 
                  help="append output to existing file (create a new file by default)")
parser.add_option("-p", "--pvalue-thresholds", dest="pvthrs", default="0.05", 
                  help="comma separated list of p-value thresholds for BLESS data (0.05 by default)")
parser.add_option("-c", "--pvalue-column", dest="pvcol", type=int, default=7,
                  help="p-value column in bless data file (7 by default)")
parser.add_option("-M", "--mappability-dir", dest="mapdir", default="", 
                  help="path to the mappability data directory (no mappability by default)")
parser.add_option("-n", "--n-tests", dest="ntest", type=int, default=1000, 
                  help="number of permutation tests (1000 by default)")
(options, args) = parser.parse_args()

featr_file=options.ffile
intvl_file=options.bfile
if options.fname is None:
    pname=featr_file
else:
    pname=options.fname
if options.bname is None:
    treat=intvl_file
else:
    treat=options.bname
output_file=options.outfile
thrs=eval('[{}]'.format(options.pvthrs))
mapity_dir_name=options.mapdir
try:
    if mapity_dir_name[-1]!='/':
        mapity_dir_name+='/'
except IndexError:
    pass
ntest=options.ntest
col_pv=options.pvcol-1
appres=options.apnd
bedgraph=options.bg

# intervals file columns
col_chr = 0 # chromosome name
col_lep = 1 # left  end position
col_rep = 2 # right end position
chrom_len_file="chroms.len"#chromosome list file in mappability data directory


class fdata_map:
    def load_mapity(self, mapity_dir_name):
        if mapity_dir_name:
            self.mapity={}
            fin=open(mapity_dir_name+chrom_len_file)
            for line in fin:
                ln=line.split()
                if ln:
                    self.mapity[ln[0]]=bitarray()
                    fba=open(mapity_dir_name+ln[0]+'.ba')
                    self.mapity[ln[0]].fromfile(fba)
                    fba.close()
            fin.close()
            self.check=self.check_map
            self.count=self.count_map
    
    def count_map(self,chrom,l,r):
        return self.mapity[chrom][l:r].count()

    def check_map(self,chrom,l,r):
        return (chrom in self.mapity) and (self.count_map(chrom,l,r) > 0)
    
    def count(self,chrom,l,r):
        return max(0,r-l)

    def check(self,chrom,l,r):
        return l < r


class fdata_bed(fdata_map):
    def __init__(self, featr_file, mapity_dir_name):
        self.load_mapity(mapity_dir_name)

        points=[]
        fin=open(featr_file)
        for line in fin:
            ln=line.split()
            if ln and ln[0][0]!='#' and ln[0]!='track' and ln[0]!='browser':
                c = ln[0]
                l, r = int(ln[1]), int(ln[2])
                if self.check(c,l,r):
                    points.append((c,l,r))
        fin.close()
        points.sort()
        
        self.left=[]
        self.right=[]
        last=points[0]
        end=last[2]
        for current in points[1:]:
            if current[0]==last[0] and current[1]<=end:
                end=max(end,current[2])
            else:
                self.left.append((last[0],last[1]))
                self.right.append((last[0],end))
                last=current
                end=last[2]
        self.left.append((last[0],last[1]))
        self.right.append((last[0],end))
        del points

    def featovl(self, chrom, l, r, default=0):
        overlap=0
        bil=bisect_left(self.right,(chrom,l))
        bir=bisect_right(self.left,(chrom,r))            
        for i in xrange(bil,bir):
            overlap += self.count(chrom, max(l,self.left[i][1]), min(r,self.right[i][1]))
        if self.count(chrom, l, r)==0:
            return default
        else:
            return float(overlap)/self.count(chrom, l, r)
#            overlap+=self.mapity[chrom][max(l,self.left[i][1]) : min(r,self.right[i][1])+1].count()
#        return float(overlap)/self.mapity[chrom][l:(r+1)].count()

class fdata_bg(fdata_map):
    def __init__(self, featr_file, mapity_dir_name):
        self.load_mapity(mapity_dir_name)

        self.bgdata=[]
        fin=open(featr_file)
        for line in fin:
            ln=line.split()
            if ln and ln[0][0]!='#' and ln[0]!='track' and ln[0]!='browser':
                c = ln[0]
                l, r = int(ln[1]), int(ln[2])
                try:
                    v=int(ln[3])
                except ValueError:
                    v=float(ln[3])
                if self.check(c,l,r):
                    self.bgdata.append((c,l,r,v))
        fin.close()
        self.bgdata.sort()
    
    def featovl(self, chrom, l, r, default=0):
        sumval=0.0
        lenval=0
        i = bisect_left(self.bgdata,(chrom,r,r,0))-1
        while i>=0:
            fc,fl,fr,fv=self.bgdata[i]
            if fc!=chrom or fr<=l:
                break
            ovlen=self.count(chrom, max(l,fl), min(r,fr))
            lenval+=ovlen
            sumval+=ovlen*fv
            i-=1
        if lenval==0:
            return default
        else:
            return sumval/lenval


class ovl_data:
    def __init__(self, fdata, intvl_file, col_pv, thrs):
        self.thrs=thrs
        self.bas=[bitarray() for t in self.thrs]
        self.featvals=[]
        fin=open(intvl_file)
        for line in fin:
            ln=line.split()
            if ln and ln[0]!='chrnum':
                c=ln[col_chr]
                l=int(ln[col_lep])
                r=int(ln[col_rep])+1
                pv=float(ln[col_pv])
                if fdata.check(c,l,r):
                    self.featvals.append(fdata.featovl(c,l,r))
                for i,ba in enumerate(self.bas):
                    ba.append(pv <= self.thrs[i])
        fin.close()

    def prop_sample(self, ba):
        sumv=0.0
        count=0
        for v,p in izip(self.featvals,ba):
            if p:
                sumv+=v
                count+=1
        return sumv/count
    
    def process(self, ntest):
        frac_all=sum(self.featvals)/len(self.featvals)
        for thr,ba in izip(self.thrs, self.bas):
            frac_sample=self.prop_sample(ba)
            pba=bitarray(ba)
            fracs=[]
            for n in xrange(ntest):
                shuffle(pba)
                fracs.append(self.prop_sample(pba))
            fracs.sort()
            pval_enrt=1-float(bisect_left(fracs,frac_sample))/ntest
            pval_depl=float(bisect_right(fracs,frac_sample))/ntest
            try:
                prop=frac_sample/frac_all
            except ZeroDivisionError:
                prop=0
            yield thr, frac_all, frac_sample, prop, pval_enrt, pval_depl

#load mappability and feature data
if bedgraph:
    fdata=fdata_bg(featr_file, mapity_dir_name)
else:
    fdata=fdata_bed(featr_file, mapity_dir_name)

#load bless data
odata=ovl_data(fdata, intvl_file, col_pv, thrs)
del fdata

#process data
if appres:
    fout=open(output_file,'a')
else:
    fout=open(output_file,'w')    
    fout.write('feature\ttreatment\tpv_threshold\tlevel_all\tlevel_fragile\tlevel_proportion\tpval_enrichment\tpval_depletion\n')
for res in odata.process(ntest):
    fout.write('{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n'.format(pname, treat, *res))
fout.close()
