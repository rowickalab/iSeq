//This software is part of iSeq suite (breakome.eu)
//Hygestat_bed Version : 1.0
#include <hygestat_bed.hpp>
int main (int argc, char**argv){
    string chrReadsFileName ="chrReads.txt";
    string argshelp="usage:> hygestat_bed <sequenced_data_directory_1> <sequenced_data_directory_2> <window interval> <bed file>";
    string dir1="./";
    if (argc < 2){
      cout << endl <<argshelp;
      cout << endl << "Please Input sequenced_data_directory_experiment (treated) ";
      cin >> dir1;
    }
    else{
      dir1=argv[1];
    }
    if(checkFile(dir1+chrReadsFileName)!=1){cout << endl << dir1+chrReadsFileName;terminate(1);}
    string dir2="./";
    if (argc < 3){
      cout << endl << argshelp;
      cout << endl << "Please Input sequenced_data_directory_control (untreated) ";
      cin >> dir2;
    }
    else
      dir2=argv[2];
    if (checkFile(dir2+chrReadsFileName)!=1){cout << endl << dir2+chrReadsFileName;terminate(3);}

    string window_siz="";
    unsigned int size_window;
    if(argc<4){
      cout<<endl<<argshelp;
      cout<<endl<<"Input interval size around cutting site";
      cin>>window_siz;
    }
    else
      window_siz=argv[3];
      stringstream ss_window(window_siz);
      ss_window>>size_window;
    string bedFileName="";
    if(argc<5){
      cout<<endl<<argshelp;
      cout<<endl<<"Input AsiSI Bed File Name";
      cin>>bedFileName;
    }
    else
      bedFileName=argv[4];
    if(checkFile(bedFileName)!=1){cerr<<endl<<"Bed file cannot be opened";terminate(5);}
   
    cout<<"                     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n";
    cout<<"                     $$$                                                                                                                   $$$\n";
    cout<<"                     $$$ Thanks for using Hygestat regions from Rowicka lab (UTMB Health Galveston). Check the results in output.txt file! $$$\n";
    cout<<"                     $$$                                                                                                                   $$$\n";
    cout<<"                     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"<<endl;

    vector<BED_LINE> bedData;
    ifstream bedFile(bedFileName.c_str());
    while(!bedFile.eof()){
	string line="";
	getline(bedFile,line);
	unsigned int columns=0;
	string::size_type tab=0;
/*	cout<<endl<<line;WAITUSER*/
	string s_chrNum,s_startPos,s_endPos,site,n_id,point;
	do{
	  tab=line.find_first_of("\t");
	  columns++;
	    switch (columns){
	      case 1:s_chrNum=line.substr(0,tab);
	      break;
	      case 2:s_startPos=line.substr(0,tab);
	      break;
	      case 3:s_endPos=line.substr(0,tab);
	      break;
	      case 4:site=line.substr(0,tab);
	      break;
	      case 5:n_id=line.substr(0,tab);
	      break;
	      case 6:point=line.substr(0,tab);
	      break;
	      default:
		break;
	    }
	    line=line.substr(tab+1,line.size());
	}while(tab!=string::npos);
	if(columns>=3){
	  unsigned int chrNum=extract_chrnum(s_chrNum,1);
	  if(chrNum==0){
	    cerr<<endl<<"error determining Chromosome Number"<<s_chrNum;
	  }
	  unsigned int startPos=0,endPos=0;
	  stringstream ss_startPos(s_startPos),ss_endPos(s_endPos);
	  ss_startPos>>startPos;
	  ss_endPos>>endPos;
	  startPos = startPos-size_window/2+2;
	  endPos   = endPos+size_window/2-4;
	  bedData.push_back({chrNum,startPos,endPos});
	}
    }
    cerr<<endl<<bedData.size()<<" lines read from BED file";
    sort(bedData.begin(),bedData.end(),bed_data_sort_fun_chrBegin);
    stable_sort(bedData.begin(),bedData.end(),bed_data_sort_fun_chrNum);
    vector<WINDOW_DATA>outData;
    {
	vector <CHR_READS> ChrList1, ChrList2;
	getChrReads(dir1+chrReadsFileName,ChrList1);
	getChrReads(dir2+chrReadsFileName,ChrList2);
	if (ChrList1.size()!=ChrList2.size()){
	  cerr << endl << ChrList1.size() << "  " << ChrList2.size() << " Chromosome size mismatch"; WAITUSER;
	}
	for(vector<CHR_READS>::iterator c=ChrList1.begin();c!=ChrList1.end();++c){
	  vector<BED_REGION> bedRegion;
	  for(vector<BED_LINE>::iterator b=bedData.begin();b!=bedData.end();++b){
	    if((*c).chrNum==(*b).chrNum){
	      bedRegion.push_back({(*b).chrBegin,(*b).chrEnd});
/*	      bedData.erase(b);*/
	     }
	   }
	  calcHypergeometricPval((*c).chrNum,chrReadsFileName,dir1,dir2,outData,bedRegion);
	}
    }
    ofstream out("output.txt");
    /*for(vector<WINDOW_DATA>::iterator o=outData.begin();o!=outData.end();++o){
      out<<endl<<"chr"<<convert_chrnum_to_string((*o).chrNum)<<"\t"<<(*o).windowStart<<"\t"<<(*o).windowEnd<<"\t"<<(*o).pval<<"\t"<<(*o).windowEnd-(*o).windowStart+1<<"\t" \
      <<(*o).windowReads1<<"\t"<<(*o).windowReads2;
    }*/

    sort(outData.begin(),outData.end(),SortOutDataPvalFun);
    vector<double> pvalList;
    for(vector<WINDOW_DATA>::iterator iw=outData.begin();iw!=outData.end();++iw){
      if((*iw).pval<2.0){
	  pvalList.push_back((*iw).pval);
      }
    }
    vector<double>qValList;
    vector<double>qValList2;
    bh(pvalList,qValList);
    bonferroni(pvalList,qValList2);
    if(pvalList.size()!=qValList.size() || pvalList.size()!=qValList2.size()){
	cerr<<endl<<"Oops BH procedure failed!";
	terminate(9);
    }

    vector<WINDOW_DATA>::iterator iw=outData.begin();
    vector<double>::iterator q=qValList.begin();
    for(;iw!=outData.end(),q!=qValList.end();++iw,++q){
      (*iw).qval=(*q);
    }
    vector<double>::iterator b=qValList2.begin();
    iw=outData.begin();
    for(;iw!=outData.end(),b!=qValList2.end();++iw,++b){
      (*iw).qval2=(*b);
    }
    sort(outData.begin(),outData.end(),SortOutDataWindowStartFun);
    stable_sort(outData.begin(),outData.end(),SortOutDataChrNumFun);
    iw=outData.begin();
    cout.precision(10);
    for(;iw!=outData.end();++iw){
	out<<"chr"<<convert_chrnum_to_string((*iw).chrNum)<<"\t"<<(*iw).windowStart<<"\t"<<(*iw).windowEnd<<"\t"<<(*iw).windowEnd-(*iw).windowStart<<"\t" \
	<<(*iw).windowReads1<<"\t"<<(*iw).windowReads2<<"\t"<<(*iw).pval<<"\t"<<(*iw).qval<<"\t"<<(*iw).qval2<<"\t"<<-1*log((*iw).pval)<<"\t"<<-1*log((*iw).qval)<<endl;
    }
}


