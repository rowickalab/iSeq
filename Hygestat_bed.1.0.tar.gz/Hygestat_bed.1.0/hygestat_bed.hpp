//This software is part of iSeq suite (breakome.eu)
//hygestat_bed Version : 1.0

#include<iostream>
#include<fstream>
#include<climits>
#include<vector>
#include<string>
#include<algorithm>
#include<sstream>
#include<fstream>
#include<cmath>
#include<map>
#include <gsl/gsl_cdf.h>
#include <boost/iostreams/device/file.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/iostreams/stream_buffer.hpp>
#define WAITUSER cout << endl << "Press Return";cin.get();
#define X_CHROMOSOME 1000
#define Y_CHROMOSOME 1001
#define MITOCHONDRION 1002

using namespace std;
struct CHR_READS{
  unsigned int chrNum;
  unsigned int reads;
};

struct SEQUENCE_READS{
  unsigned int chrPos;
  unsigned int hits;
};

struct MAPPABILITY_DATA{
  unsigned int readSize;
  unsigned int chrSize;
  unsigned int chrNum;
  vector<bool> mappabilityMap;
};

struct WINDOW_DATA{
/*  string geneName;*/
  unsigned int chrNum;
  unsigned int windowReads1;
  unsigned int windowReads2;
  unsigned int windowStart;
  unsigned int windowEnd;
  double pval;
  double qval;
  double qval2;
};
struct SortByChrPos
{
  bool operator () (const SEQUENCE_READS & lhs , const SEQUENCE_READS & rhs) const
  {
    return lhs.chrPos < rhs.chrPos;
  }
};


struct outputDataType{
    unsigned int ps,sa,sp,ss;
    double pval;
    string annotations;
};

struct BED_LINE{
  unsigned int chrNum;
  unsigned int chrBegin;
  unsigned int chrEnd;
};

struct BED_REGION{
  unsigned int chrBegin;
  unsigned int chrEnd;
};

bool bed_data_sort_fun_chrNum(struct BED_LINE b1, struct BED_LINE b2){
  return (b1.chrNum < b2.chrNum);
}

bool bed_data_sort_fun_chrBegin(struct BED_LINE b1, struct BED_LINE b2){
  return (b1.chrBegin < b2.chrBegin);
}

int checkFile(string fileName)
{
  ifstream fileOpenTest;
  int isFileOpen=-1;
  fileOpenTest.open(fileName.c_str());
  if (fileOpenTest.is_open())
  {
    isFileOpen=1;
    fileOpenTest.close();
  }
  if (isFileOpen==-1) cout << endl << "File" << fileName <<" cannot be opened";
  return isFileOpen;
}

unsigned int extract_chrnum(string s_chrNum, bool XY){
  unsigned int len=s_chrNum.size();
  unsigned int count =0;
  unsigned int chrNum=0;
  //cout << endl << "LEN" << len;WAITUSER;
  for (unsigned int n=len; n>0; --n)
  {
    char c = s_chrNum[n-1];
   if (c >= '0' && c<='9'){
      ++count;
      if (count==1)
      {
	chrNum+= (c-'0');
      }
      else if (count==2)
      {
	chrNum+= (c-'0')*10;
      }
      else if (count==3)
      {
	chrNum+= (c-'0')*100;
      }
      else if (count > 3)
	chrNum=0;
    }
    //cout << endl << "char:" << c << " len:" << n << " chrnum" << chrNum;WAITUSER;
  }

  if (chrNum==0 && XY==0)
  {
    for (unsigned int n=len; n>0; --n)
    {
      char c = s_chrNum[n-1];
      if (c == 'X' || c== 'V' || c=='I'){
	++count;
	if (count==1)
	{
	  if (c=='X')
	    chrNum+=10;
	  else if (c=='V')
	    chrNum+=5;
	  else if (c=='I')
	    chrNum+=1;
	}
      else if (count>1 && count <=4)
	{
	 // cout << endl << " " << count << " " << char(s_chrNum[n]); WAITUSER;
	  if (c < char(s_chrNum[n])){
	    if (c=='X')
	      chrNum-=10;
	    else if (c=='V')
	      chrNum-=5;
	    else if (c=='I')
	      chrNum-=1;
	  }
	  else if (c >= char(s_chrNum[n])){
	    if (c=='X')
	    chrNum+=10;
	  else if (c=='V')
	    chrNum+=5;
	  else if (c=='I')
	    chrNum+=1;
	  }
	}
	else if (count >4)
	  chrNum=0;
      }
    }
    //cout << endl << "Roman Numeral " << chrNum; WAITUSER;
  }
  else if (chrNum==0 && XY==1)//XY chromosome
    for (unsigned int n=len; n>0; --n){
      char c=s_chrNum[n-1];
      if (c=='X')
	chrNum=X_CHROMOSOME;
      else if (c=='Y')
	chrNum=Y_CHROMOSOME;
    }
  return chrNum;
}

string convert_chrnum_to_string2(unsigned int chrNum){
  string s_chrNum="";
  stringstream ss_chrNum;
  if (chrNum <10){
    string s_chrNumTemp="";
    ss_chrNum << chrNum;
    ss_chrNum >> s_chrNumTemp;
    s_chrNum = "0" + s_chrNumTemp;
  }
  else if (chrNum <X_CHROMOSOME){
    ss_chrNum << chrNum;
    ss_chrNum >> s_chrNum;
  }
  else {
    char c_chrNum=chrNum-X_CHROMOSOME+'X';
    s_chrNum=c_chrNum;
  }

  return s_chrNum;
}

string convert_chrnum_to_string(unsigned int chrNum){
  string s_chrNum;
  stringstream ss_chrNum;
  if (chrNum <X_CHROMOSOME){
    ss_chrNum << chrNum;
    ss_chrNum >> s_chrNum;
  }
  else {
    char c_chrNum=chrNum-X_CHROMOSOME+'X';
    s_chrNum=c_chrNum;

  }
  return s_chrNum;
}

int getChrReads(string FileName, vector<CHR_READS> &chrList ){
  ifstream controlChrFile(FileName.c_str());
  unsigned int totalReads=0;
  while(!controlChrFile.eof()){
    string line;
    getline (controlChrFile,line);
    string::size_type tab_location;
    tab_location=line.find_first_of('\t');
    CHR_READS crtemp;
    unsigned int chrNum = extract_chrnum(line.substr(0,tab_location),true);
    if (chrNum!=0){
      crtemp.chrNum=chrNum;
      stringstream ss_reads(line.substr(tab_location+1));
      unsigned int reads;
      ss_reads >> reads;
      crtemp.reads=reads;
      totalReads+=reads;
      chrList.push_back(crtemp);
    }
  }
  return totalReads;
}

bool OutputSortFun(struct outputDataType od1, struct outputDataType od2){
  return (od1.pval < od2.pval);
}

void terminate(int retval)
{
  cout << endl << "Terminating! because of Error " << retval << endl;
  exit(retval);
}

bool sortSeqReadsFun (struct SEQUENCE_READS s1, struct SEQUENCE_READS s2)
{
  return (s1.chrPos < s2.chrPos);
}

int getSequenceReads(string Dir, vector<SEQUENCE_READS> &sequenceReads,unsigned int chrNum){
  if (checkFile(Dir+"/chr"+convert_chrnum_to_string(chrNum)+"+.hits.txt")!=1){ cerr << Dir+"/chr"+convert_chrnum_to_string(chrNum)+"+.hits.txt"; terminate(chrNum);}
  if (checkFile(Dir+"/chr"+convert_chrnum_to_string(chrNum)+"-.hits.txt")!=1){ cerr << Dir+"/chr"+convert_chrnum_to_string(chrNum)+"-.hits.txt"; terminate(chrNum);}
  ifstream chrFileW;
  chrFileW.open((Dir+"/chr"+convert_chrnum_to_string(chrNum)+"+.hits.txt").c_str());
  ifstream chrFileC;
  chrFileC.open((Dir+"/chr"+convert_chrnum_to_string(chrNum)+"-.hits.txt").c_str());
  vector <SEQUENCE_READS> reads;
  while (!chrFileW.eof()){
    string line="";
    getline(chrFileW,line);
    stringstream ss(line);
    SEQUENCE_READS tmp;
    ss >> tmp.hits >> tmp.chrPos;
    if(!chrFileW.eof()){
    reads.push_back(tmp);
  }
  }
  while (!chrFileC.eof()){
    string line="";
    getline(chrFileC,line);
    stringstream ss(line);
    SEQUENCE_READS tmp;
    ss >> tmp.hits >> tmp.chrPos;
    if(!chrFileC.eof()){
    reads.push_back(tmp);
    }
  }
  sort(reads.begin(),reads.end(),sortSeqReadsFun);
// for (vector <SEQUENCE_READS>::iterator i=reads.begin();i<reads.end();++i)
//     cout << endl << (*i).chrPos<<"\t"<<(*i).hits;
//   WAITUSER;
  sequenceReads=reads;
  return 0;
}

double hgcalc_gte(unsigned int ps/*pop. size*/, unsigned int sa/*sample size*/,unsigned int sp/*Success Pop.*/ \
,unsigned int ss/*Success Sample*/){
  double pval=1.0;
  if (ss>=1&&ps>=sa&&ps>=sp&&sa>=ss){
     pval=gsl_cdf_hypergeometric_Q(ss-1,sp,ps-sp,sa);
  }
  return pval;
}

int calcHypergeometricPval(unsigned int chrNum,string chrReadsFileName,string Dir1,string Dir2, \
vector<WINDOW_DATA> &outData, vector<BED_REGION>&bedRegion)
{
      unsigned int numWindows=0;
      vector <CHR_READS> ChrList1, ChrList2;
      //cerr<<endl<<"Total Reads in data1 = "<<
      getChrReads(Dir1+chrReadsFileName,ChrList1);
     //cerr<<endl<<"Total Reads in data2 = "<<
      getChrReads(Dir2+chrReadsFileName,ChrList2);
      unsigned int currentChrNum=chrNum;
    //  cerr<<endl<<"Chr"<<chrNum;
      unsigned int Reads1=0;
      for (vector <CHR_READS>::iterator iC1=ChrList1.begin();iC1!=ChrList1.end();++iC1){
	  if ((*iC1).chrNum==currentChrNum)
	  {
	    Reads1=(*iC1).reads;
	  }
      }
      unsigned int Reads2=0;
      for (vector <CHR_READS>::iterator iC2=ChrList2.begin();iC2!=ChrList2.end();++iC2){
	  if ((*iC2).chrNum==currentChrNum)
	  {
	    Reads2=(*iC2).reads;
	  }
      }
      vector <SEQUENCE_READS> SequenceReads1, SequenceReads2;
      getSequenceReads(Dir1,SequenceReads1,currentChrNum);
      getSequenceReads(Dir2,SequenceReads2,currentChrNum);
      vector <SEQUENCE_READS>::iterator iControlStart=SequenceReads1.begin();
      vector <SEQUENCE_READS>::iterator iExpStart=SequenceReads2.begin();
     if(bedRegion.size()){
     for(vector<BED_REGION>::iterator b=bedRegion.begin();b!=bedRegion.end();++b){
       unsigned int startPos=(*b).chrBegin;//calibrate for bowtie 0 beginning
       unsigned int endPos=(*b).chrEnd-1;
/*       cerr<<endl<<"Chr"<<convert_chrnum_to_string(chrNum)<<"\t"<<geneName<<"\t"<<WC<<"\t"<<startPos<<"\t"<<endPos<<"\t"<<endPos-startPos<<"\t"<<Reads1<<"\t"<<Reads2;WAITUSER*/
       unsigned int windowReads1=0;
       unsigned int windowReads2=0;
       unsigned int windowStart=startPos;
       unsigned int windowEnd=endPos;
       {//window1 reads
		bool hitsFound=0;
		bool firstHitFound=0;
		for (vector <SEQUENCE_READS>::iterator iC=iControlStart; iC!=SequenceReads1.end(); ++iC)
		{//find all reads in the current window
		    if (((*iC).chrPos>=windowStart) && ((*iC).chrPos<=windowEnd))//
		    {
		      if(firstHitFound==0){
			firstHitFound=1;
			iControlStart=iC;
		      }
		      hitsFound=1;
		      windowReads1+=(*iC).hits;
		    }
		    if ((*iC).chrPos > windowEnd) break;//
		}
		//cout << endl << windowStart << "\t"  << windowEnd-1 << "\t"<<windowReads1;
		if (hitsFound==0){
		}
	}
	{//window2 reads
		bool hitsFound=0;
		bool firstHitFound=0;
		for (vector <SEQUENCE_READS>::iterator iC=iExpStart; iC!=SequenceReads2.end(); ++iC)
		{
		    if (((*iC).chrPos>=windowStart) && ((*iC).chrPos<=windowEnd))
		    {
      		      if(firstHitFound==0){
			firstHitFound=1;
			iExpStart=iC;
		      }
		      hitsFound=1;
		      windowReads2+=(*iC).hits;
		    }
		    if ((*iC).chrPos > windowEnd) break;//
		}
		//cout << "\t" << windowStart << "\t"  << windowEnd-1 << "\t" << windowReads2;
		if (hitsFound==0){
		}
	 }
	 if (windowReads1>=1 && windowReads2>=0){
	      numWindows++;
	      unsigned int ps=Reads1+Reads2;/*Pop. Size*/
	      unsigned int sa=windowReads1+windowReads2;/*Sample Size*/
	      unsigned int sp=Reads1;/*Success Population*/
	      unsigned int ss=windowReads1;/*Success Sample*/
// 	      double pval= gsl_cdf_hypergeometric_Q(windowReads1-1,Reads1,Reads2,windowReads2+windowReads1);
	      double pval=hgcalc_gte(ps,sa,sp,ss);
/*	      cerr<<endl<<"Chr"<<convert_chrnum_to_string(chrNum)<<"\t"<<geneName<<"\t"<<WC<<"\t"<<startPos<<"\t"<<endPos<<"\t"<<endPos-startPos;
	      cerr<<endl<<windowReads1<<"\t"<<windowReads2<<"\t"<<Reads1<<"\t"<<Reads2<<"\t"<<pval;WAITUSER*/
     	      outData.push_back({currentChrNum,windowReads1,windowReads2,windowStart,windowEnd,pval});

	 }
	 //avoid holes in the data list, pval=2.0 for filtering later
	 else{
      	      outData.push_back({currentChrNum,windowReads1,windowReads1,windowStart,windowEnd,1.0,1.0});//change for BH correction
	 }

     }
   }
}

bool SortOutDataPvalFun (struct WINDOW_DATA s1, struct WINDOW_DATA s2){
  return (s1.pval<s2.pval);
}

bool SortOutDataWindowStartFun (struct WINDOW_DATA s1, struct WINDOW_DATA s2){
  return (s1.windowStart<s2.windowStart);
}

bool SortOutDataChrNumFun (struct WINDOW_DATA s1, struct WINDOW_DATA s2){
  return (s1.chrNum<s2.chrNum);
}

unsigned int bh(vector<double>&pvalList,vector<double>&qValList)
{
      unsigned int count=0;
      double previous_bhVal=0.0;
      unsigned listSize=pvalList.size();
      for(vector<double>::iterator p=pvalList.begin();p!=pvalList.end();++p,++count){
	#define DEBUGPVAL
	#ifdef DEBUGPVAL
	  if ((*p)>1.0 || (*p)<0.0){
	    cerr<<endl<<(*p)<<" bad pval!";
	  }
	#endif
	double bhVal=(*p)*listSize/(count+1);
	if(bhVal>1.0){
	  bhVal=1.0;
	}
	if(bhVal<previous_bhVal){
	  bhVal=previous_bhVal;
	}
	previous_bhVal=bhVal;
	qValList.push_back(bhVal);
      }
      return(qValList.size());
}

unsigned int bonferroni(vector<double>&pvalList,vector<double>&qValList)
{
      unsigned listSize=pvalList.size();
      for(vector<double>::iterator p=pvalList.begin();p!=pvalList.end();++p){
	#define DEBUGPVAL
	#ifdef DEBUGPVAL
	  if ((*p)>1.0 || (*p)<0.0){
	    cerr<<endl<<(*p)<<" bad pval!";
	  }
	#endif
	double bonferroniVal=(*p)*listSize;
	if(bonferroniVal>1.0){
	  bonferroniVal=1.0;
	}
	qValList.push_back(bonferroniVal);
      }
      return(qValList.size());
}




