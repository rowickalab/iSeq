DataDirect=Path_to_the_data_from_hygestat

TreatSamp=${DataDirect}/treated

NonTreatSamp=${DataDirect}/non_treated

WindowSize=1000

Soft_direct=Path_to_the_software_directory

${Soft_direct}/hygestat_gense ${TreatedSamp}/input_close_barcode(or input_no_barcode)/ ${NonTreatSamp}/input_close_barcode(or input_no_barcode)/ $WindowSize user_given_region.txt

cat output.txt |awk '{if($8<=0.05) print$0}' > signif_output.txt
