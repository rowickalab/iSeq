while read Line
do echo "$Line"
for((x=1; x<=19; ++x));
do
perl ./perl_map.pl ../chr${x}.fa > chr${x}_1
done
perl ./perl_map.pl ../chrX.fa > chrX_1
perl ./perl_map.pl ../chrY.fa > chrY_1
perl ./perl_map.pl ../chrM.fa > chrM_1
done < ../fragfiles1.txt



