#!/usr/bin/perl 
use Bio::SeqIO;
# assume one chromosome per file, one fasta sequence
$infile = $ARGV[0];

my $seqio = Bio::SeqIO->new(-file => $infile, '-format' => 'Fasta');
my $seql = $seqio->next_seq; my $seq = $seql->seq;

$l = length $seq;
for ($i = 0; $i < $l-1; ++$i) { 
   my @sequence = (substr $seq, $i, 1), "\n"; 
  # print "\n";
  print @sequence, "\n";
# my @output = "$infile._45";
# open (out, '>', @output) or die "$!\n";
# print @sequence out, "\n";
 #print out $sequence;
# close out;
    }
exit;

