while read LINE
do
echo $LINE
bowtie /data24TB/store/julesberlin/mouse/mm10 ./$LINE --concise -p2 -l45 -n0 -r -a -m2  > bowtie_$LINE.txt
chrname=${LINE%_*} #split
mapcheck/mapcheck bowtie_$LINE.txt map_1/${chrname}_1
done < fragfiles.txt
rename map_bowtie_ map_ map_bowtie_*
rm *_45 bowtie_chr*
