#include "mapcheck.hpp"
int main (int argc, char **argv){
     unsigned int argcnum=1;
     string bowtieFileName="";
     string argshelp="usage:> mapcheck <bowtie condensed file.txt> <single bp fragmented chromosome file for e.g. chr01_1>";
     if (argc<=argcnum){
       cout << endl << argshelp;
       cout << endl << "Please input bowtie condensed output file name";
       cin >> bowtieFileName;
      }
      else
	bowtieFileName=argv[argcnum++];
      if (checkFile(bowtieFileName)!=1) terminate(1);
      string outputMapFileName="";
      string outputMapFilePath="./";
      string::size_type slashPos=bowtieFileName.find_last_of('/');
      if (slashPos!=string::npos){
	outputMapFilePath=bowtieFileName.substr(0,slashPos+1);
	outputMapFileName=outputMapFilePath+"map_"+bowtieFileName.substr(slashPos+1);
      }
      else
	outputMapFileName=outputMapFilePath+"map_"+bowtieFileName;
	
      cerr << endl << outputMapFileName;
      //WAITUSER;
      string chrFileName="";
      if (argc<=argcnum){
       cout << endl << argshelp;
       cout << endl << "Please input single bp fragmented chromosome file name";
       cin >> chrFileName;
      }
      else
	chrFileName=argv[argcnum++];
      if (checkFile(chrFileName)!=1) terminate(1);
      boost::iostreams::stream_buffer<boost::iostreams::file_source> chrFileSource(chrFileName.c_str()); 
      istream chrFile(&chrFileSource);
      unsigned int chrLength=0;
      string line="";
      while(!chrFile.eof()){
	getline(chrFile,line);
	if(line.size()==1)chrLength++;
      }
      cerr << endl << "Chr Length " << chrLength<<"\t";
      vector <unsigned int>chrMap(chrLength,0);
      cerr << chrMap.size();
      boost::iostreams::stream_buffer<boost::iostreams::file_source> btFileSource(bowtieFileName.c_str()); 
      istream btFile(&btFileSource);
      while(!btFile.eof()){
	string line="";
	getline(btFile,line);
	string s_chrPos;
	string::size_type plusPos=line.find_first_of('+');
	if (plusPos!=string::npos){
	  s_chrPos=line.substr(0,plusPos);
	  //cout << endl << s_chrPos; WAITUSER;
	  stringstream ss_chrPos(s_chrPos);
	  unsigned int chrPos=0;
	  ss_chrPos >> chrPos;
	  chrMap[chrPos]++;
	}
      }
      boost::iostreams::stream_buffer<boost::iostreams::file_sink> mapFileSink(outputMapFileName.c_str()); 
      ostream mapFileOut(&mapFileSink);
      for (vector <unsigned int>::iterator i=chrMap.begin();i!=chrMap.end();++i){
	if (*i!=0){
	  mapFileOut << *i << endl;
	  //cout << *i << endl;
	}
	else{
	  mapFileOut << "2" << endl;
	  //cout << "2" << endl;
	}
      }
      if (mapFileSink.is_open()) mapFileSink.close();
}
  