#to be used with hygestat_bless output
STEMPLOTWINDOWSIZE=48000
HEATMAPWINDOWSIZE=48000
PLOIDYMAPWINDOWSIZE=${HEATMAPWINDOWSIZE}
MAPABILITYMAPWINDOWSIZE=${HEATMAPWINDOWSIZE}

STEMPLOTFILESDIRECTORY=link_to_hygestat_bless_output_directory
#echo $STEMPLOTFILESDIRECTORY
for((x=1;x<=22;x++));
do
	cat ${STEMPLOTFILESDIRECTORY}/${STEMPLOTWINDOWSIZE}_output.txt | grep -P "^chr0${x}\t|^chr${x}\t" | awk '{print $2/2+$3/2"\t"log($7)*-10/log(10)}' > chr${x}_STEM_${STEMPLOTWINDOWSIZE}.txt
done
        cat ${STEMPLOTFILESDIRECTORY}/${STEMPLOTWINDOWSIZE}_output.txt | grep -P "^chrX\t" | awk '{print $2/2+$3/2"\t"log($7)*-10/log(10)}' > chrX_STEM_${STEMPLOTWINDOWSIZE}.txt
        cat ${STEMPLOTFILESDIRECTORY}/${STEMPLOTWINDOWSIZE}_output.txt | grep -P "^chrY\t" | awk '{print $2/2+$3/2"\t"log($7)*-10/log(10)}' > chrY_STEM_${STEMPLOTWINDOWSIZE}.txt

for((x=1;x<=22;x++));
do

	cat ${STEMPLOTFILESDIRECTORY}/${STEMPLOTWINDOWSIZE}_output.txt | grep -P "^chr0${x}\t|^chr${x}\t" |  awk '{print '$x'"\t"($7<=0.05?2:1.3)"\t"$2"\t"$3}' > chr${x}_PLOIDY_${PLOIDYMAPWINDOWSIZE}.txt
done
        cat ${STEMPLOTFILESDIRECTORY}/${STEMPLOTWINDOWSIZE}_output.txt | grep -P "^chrX\t" | awk '{print "88\t"($7<=0.05?2:1.3)"\t"$2"\t"$3}' > chrX_PLOIDY_${PLOIDYMAPWINDOWSIZE}.txt
        cat ${STEMPLOTFILESDIRECTORY}/${STEMPLOTWINDOWSIZE}_output.txt | grep -P "^chrY\t" | awk '{print "89\t"($7<=0.05?2:1.3)"\t"$2"\t"$3}' > chrY_PLOIDY_${PLOIDYMAPWINDOWSIZE}.txt

for((x=1;x<=22;x++));
do

        cat ${STEMPLOTFILESDIRECTORY}/${STEMPLOTWINDOWSIZE}_output.txt | grep -P "^chr0${x}\t|^chr${x}\t" |  awk '{print '$x'"\t"'$MAPABILITYMAPWINDOWSIZE'/($3-$2)"\t"$2"\t"$3}' > chr${x}_MAPABILITY_${MAPABILITYMAPWINDOWSIZE}.txt
done
        cat ${STEMPLOTFILESDIRECTORY}/${STEMPLOTWINDOWSIZE}_output.txt | grep -P "^chrX\t" |  awk '{print "88\t"'$MAPABILITYMAPWINDOWSIZE'/($3-$2)"\t"$2"\t"$3}' > chrX_MAPABILITY_${MAPABILITYMAPWINDOWSIZE}.txt
        cat ${STEMPLOTFILESDIRECTORY}/${STEMPLOTWINDOWSIZE}_output.txt | grep -P "^chrY\t" |  awk '{print "89\t"'$MAPABILITYMAPWINDOWSIZE'/($3-$2)"\t"$2"\t"$3}' > chrY_MAPABILITY_${MAPABILITYMAPWINDOWSIZE}.txt

