%This software is part of iSeq suite (breakome.eu)
%Hygestat_plots Version 1.0
clear all;
x=1;
y=0;
firstChr=1;
lastChr=22;
heatmapWinSize='48000';

for chrnum=firstChr:lastChr
    c=int2str(chrnum);
    filenameStem=strcat('chr',c,'_STEM_48000.txt');
    STEM=load (filenameStem);
    filenamePloidy=strcat('chr',c,'_PLOIDY_',heatmapWinSize,'.txt');
    ploidy=load (filenamePloidy);
    filenameMapability=strcat('chr',c,'_MAPABILITY_',heatmapWinSize,'.txt');
    mapability=load (filenameMapability);
    chrs=int2str(ploidy(:,1));
    types=ploidy(:,2)';
    starts=ploidy(:,3)';
    ends=ploidy(:,4)';
    cnvStruct=struct('Chromosome',chrs,'CNVType',types,'Start',starts,'End',ends);
    chrs=int2str(mapability(:,1));
    types=mapability(:,2)';
    starts=mapability(:,3)';
    ends=mapability(:,4)';
    cnv2Struct=struct('Chromosome',chrs,'CNVType',types,'Start',starts,'End',ends);
    hs_cytobands = cytobandread('hs_cytoBand_hg19.txt');
    hfig=figure;
    set(hfig,'Position',[0,0,2000,550]);
    stem(STEM(:,1),STEM(:,2),'.');
    ylim([0 50]);
    set(gca,'XTick',0);
    set(gca,'XTickLabel','');
    %set(gca,'YTick',0);
    %set(gca,'YTickLabel','');
    ylabel('-10.log_1_0({\itq}-value)','fontsize',12);
    chromosomeplot2(hs_cytobands,chrnum,'Orientation',2,'cnv',cnvStruct,'map',cnv2Struct,'addtoplot',gca,'ShowBandLabel',false);
end

if x==1
    c='X';
    filenameStem=strcat('chr',c,'_STEM_48000.txt');
    STEM=load (filenameStem);
    filenamePloidy=strcat('chr',c,'_PLOIDY_',heatmapWinSize,'.txt');
    ploidy=load (filenamePloidy);
    filenameMapability=strcat('chr',c,'_MAPABILITY_',heatmapWinSize,'.txt');
    mapability=load (filenameMapability);
    chrs=char(ploidy(:,1));
    types=ploidy(:,2)';
    starts=ploidy(:,3)';
    ends=ploidy(:,4)';
    cnvStruct=struct('Chromosome',chrs,'CNVType',types,'Start',starts,'End',ends);
    chrs=char(mapability(:,1));
    types=mapability(:,2)';
    starts=mapability(:,3)';
    ends=mapability(:,4)';
    cnv2Struct=struct('Chromosome',chrs,'CNVType',types,'Start',starts,'End',ends);
    hs_cytobands = cytobandread('hs_cytoBand_hg19.txt');
    hfig=figure;
    set(hfig,'Position',[0,0,2000,550]);
    stem(STEM(:,1),STEM(:,2),'.');
    ylim([0 50]);
    set(gca,'XTick',0);
    set(gca,'XTickLabel','');
    %set(gca,'YTick',0);
    %set(gca,'YTickLabel','');
    ylabel('-10.log_1_0({\itq}-value)','fontsize',12);
    chromosomeplot2(hs_cytobands,c,'Orientation',2,'cnv',cnvStruct,'map',cnv2Struct,'addtoplot',gca,'ShowBandLabel',false);
end
if y==1
    c='Y';
    filenameStem=strcat('chr',c,'_STEM_48000.txt');
    STEM=load (filenameStem);
    filenamePloidy=strcat('chr',c,'_PLOIDY_',heatmapWinSize,'.txt');
    ploidy=load (filenamePloidy);
    filenameMapability=strcat('chr',c,'_MAPABILITY_',heatmapWinSize,'.txt');
    mapability=load (filenameMapability);
    chrs=char(ploidy(:,1));
    types=ploidy(:,2)';
    starts=ploidy(:,3)';
    ends=ploidy(:,4)';
    cnvStruct=struct('Chromosome',chrs,'CNVType',types,'Start',starts,'End',ends);
    chrs=char(mapability(:,1));
    types=mapability(:,2)';
    starts=mapability(:,3)';
    ends=mapability(:,4)';
    cnv2Struct=struct('Chromosome',chrs,'CNVType',types,'Start',starts,'End',ends);
    hs_cytobands = cytobandread('hs_cytoBand_hg19.txt');
    hfig=figure;
    set(hfig,'Position',[0,0,2000,550]);
    stem(STEM(:,1),STEM(:,2),'.');
    ylim([0 50]);
    set(gca,'XTick',0);
    set(gca,'XTickLabel','');
    set(gca,'YTick',0);
    set(gca,'YTickLabel','');
    ylabel('-10.log_1_0({\itq}-value)','fontsize',12);
    chromosomeplot2(hs_cytobands,c,'Orientation',2,'cnv',cnvStruct,'map',cnv2Struct,'addtoplot',gca,'ShowBandLabel',false);
end

