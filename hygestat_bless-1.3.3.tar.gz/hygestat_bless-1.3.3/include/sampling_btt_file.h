#ifndef SAMPLING_BTT_FILE_H
#define SAMPLING_BTT_FILE_H

#include<iostream>
#include<fstream>
#include<climits>
#include<vector>
#include<string>
#include<algorithm>
#include<sstream>
#include<fstream>
#include<cmath>
#include<cctype>
#include <random>
#include <ctime>

#include "hygestat.h"



extern bool DEBUG;          // output debugging information?

#endif

