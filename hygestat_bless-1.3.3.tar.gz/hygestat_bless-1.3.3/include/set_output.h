#ifndef SET_OUTPUT_H
#define SET_OUTPUT_H

#include<iostream>
#include<fstream>
#include<climits>
#include<vector>
#include<string>
#include<algorithm>
#include<sstream>
#include<fstream>
#include<cmath>
#include<cctype>
#include <random>
#include <ctime>

#include "hygestat.h"

extern bool TELOMERE;         // Are counting the number of barcoded telomeres?


#endif

