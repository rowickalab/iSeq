#ifndef INIT_THREAD_H
#define INIT_THREAD_H

#include<iostream>
#include<fstream>
#include<climits>
#include<vector>
#include<string>
#include<algorithm>
#include<sstream>
#include<fstream>
#include<cmath>
#include<cctype>
#include <random>
#include <ctime>


#include "hygestat.h"

extern std::string nature_of_analysis;

#endif

