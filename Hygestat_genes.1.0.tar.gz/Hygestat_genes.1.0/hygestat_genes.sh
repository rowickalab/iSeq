DataDirect=Path_to_the_data_from_hygestat

TreatSamp=${DataDirect}/treated

NonTreatSamp=${DataDirect}/non_treated

MappaDirect=Path_to_the_precomputed_mappability

GeneCode=Path_to_the_gene_codeV12

Soft_direct=Path_to_the_software_directory

${Soft_direct}/hygestat_gense ${TreatedSamp}/input_close_barcode(or input_no_barcode)/ ${NonTreatSamp}/input_close_barcode(or input_no_barcode)/ ${MappaDirect}/ ${GeneCode}/genecodeV12.txt

cat output.txt |awk '{if($10<=0.05) print$0}' > signif_output.txt
