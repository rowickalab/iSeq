#include<iostream>
#include<fstream>
#include<climits>
#include<vector>
#include<string>
#include<algorithm>
#include<sstream>
#include<fstream>
#include<cmath>
#include<map>
#include <gsl/gsl_cdf.h>
#include <boost/iostreams/device/file.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/iostreams/stream_buffer.hpp>
#define WAITUSER cout << endl << "Press Return";cin.get();
#define X_CHROMOSOME 1000
#define Y_CHROMOSOME 1001
#define MITOCHONDRION 1002

using namespace std;
string geneFileName="";
string mapDir="";
struct CHR_READS{
  unsigned int chrNum;
  unsigned int reads;
};

struct SEQUENCE_READS{
  unsigned int chrPos;
  unsigned int hits;
};

struct MAPPABILITY_DATA{
  unsigned int readSize;
  unsigned int chrSize;
  unsigned int chrNum;
  vector<bool> mappabilityMap;
};

struct WINDOW_DATA{
  string geneName;
  unsigned int chrNum;
  unsigned int windowReads1;
  unsigned int windowReads2;
  unsigned int windowStart;
  unsigned int windowEnd;
  double pval;
  double qval;
  double qval2;
};
struct SortByChrPos
{
  bool operator () (const SEQUENCE_READS & lhs , const SEQUENCE_READS & rhs) const
  {
    return lhs.chrPos < rhs.chrPos;
  }
};


struct outputDataType{
    unsigned int ps,sa,sp,ss;
    double pval;
    string annotations;
};

struct TRANS_INFO{
    unsigned int chrStart;
    unsigned int chrEnd;
    string geneName;
    bool WC;
    string transcriptName;
};

struct TRANS_LIST{
   unsigned int chrNum;
    vector<TRANS_INFO> proteinCodingGenes;
};

struct GENE_INFO{
  unsigned int chrStart;
  unsigned int chrEnd;
  string geneName;
  bool WC;
};

struct GENES_LIST{
  unsigned int chrNum;
  vector<GENE_INFO> proteinCodingGenes;
};

int checkFile(string fileName)
{
  ifstream fileOpenTest;
  int isFileOpen=-1;
  fileOpenTest.open(fileName.c_str());
  if (fileOpenTest.is_open())
  {
    isFileOpen=1;
    fileOpenTest.close();
  }
  if (isFileOpen==-1) cout << endl << "File" << fileName <<" cannot be opened";
  return isFileOpen;
}

unsigned int extract_chrnum(string s_chrNum, bool XY){
  unsigned int len=s_chrNum.size();
  unsigned int count =0;
  unsigned int chrNum=0;
  //cout << endl << "LEN" << len;WAITUSER;
  for (unsigned int n=len; n>0; --n)
  {
    char c = s_chrNum[n-1];
   if (c >= '0' && c<='9'){
      ++count;
      if (count==1)
      {
	chrNum+= (c-'0');
      }
      else if (count==2)
      {
	chrNum+= (c-'0')*10;
      }
      else if (count==3)
      {
	chrNum+= (c-'0')*100;
      }
      else if (count > 3)
	chrNum=0;
    }
    //cout << endl << "char:" << c << " len:" << n << " chrnum" << chrNum;WAITUSER;
  }

  if (chrNum==0 && XY==0)
  {
    for (unsigned int n=len; n>0; --n)
    {
      char c = s_chrNum[n-1];
      if (c == 'X' || c== 'V' || c=='I'){
	++count;
	if (count==1)
	{
	  if (c=='X')
	    chrNum+=10;
	  else if (c=='V')
	    chrNum+=5;
	  else if (c=='I')
	    chrNum+=1;
	}
      else if (count>1 && count <=4)
	{
	 // cout << endl << " " << count << " " << char(s_chrNum[n]); WAITUSER;
	  if (c < char(s_chrNum[n])){
	    if (c=='X')
	      chrNum-=10;
	    else if (c=='V')
	      chrNum-=5;
	    else if (c=='I')
	      chrNum-=1;
	  }
	  else if (c >= char(s_chrNum[n])){
	    if (c=='X')
	    chrNum+=10;
	  else if (c=='V')
	    chrNum+=5;
	  else if (c=='I')
	    chrNum+=1;
	  }
	}
	else if (count >4)
	  chrNum=0;
      }
    }
    //cout << endl << "Roman Numeral " << chrNum; WAITUSER;
  }
  else if (chrNum==0 && XY==1)//XY chromosome
    for (unsigned int n=len; n>0; --n){
      char c=s_chrNum[n-1];
      if (c=='X')
	chrNum=X_CHROMOSOME;
      else if (c=='Y')
	chrNum=Y_CHROMOSOME;
    }
  return chrNum;
}

string convert_chrnum_to_string(unsigned int chrNum){
  string s_chrNum;
  stringstream ss_chrNum;
  if (chrNum <X_CHROMOSOME){
    ss_chrNum << chrNum;
    ss_chrNum >> s_chrNum;
  }
  else {
    char c_chrNum=chrNum-X_CHROMOSOME+'X';
    s_chrNum=c_chrNum;

  }
  return s_chrNum;
}

string convert_chrnum_to_string2(unsigned int chrNum){
  string s_chrNum="";
  stringstream ss_chrNum;
  if (chrNum <10){
    string s_chrNumTemp="";
    ss_chrNum << chrNum;
    ss_chrNum >> s_chrNumTemp;
    s_chrNum = "0" + s_chrNumTemp;
  }
  else if (chrNum <X_CHROMOSOME){
    ss_chrNum << chrNum;
    ss_chrNum >> s_chrNum;
  }
  else {
    char c_chrNum=chrNum-X_CHROMOSOME+'X';
    s_chrNum=c_chrNum;
  }

  return s_chrNum;
}


int getChrReads(string FileName, vector<CHR_READS> &chrList ){
  ifstream controlChrFile(FileName.c_str());
  unsigned int totalReads=0;
  while(!controlChrFile.eof()){
    string line;
    getline (controlChrFile,line);
    string::size_type tab_location;
    tab_location=line.find_first_of('\t');
    CHR_READS crtemp;
    unsigned int chrNum = extract_chrnum(line.substr(0,tab_location),true);
    if (chrNum!=0){
      crtemp.chrNum=chrNum;
      stringstream ss_reads(line.substr(tab_location+1));
      unsigned int reads;
      ss_reads >> reads;
      crtemp.reads=reads;
      totalReads+=reads;
      chrList.push_back(crtemp);
    }
  }
  return totalReads;
}

bool OutputSortFun(struct outputDataType od1, struct outputDataType od2){
  return (od1.pval < od2.pval);
}

void terminate(int retval)
{
  cout << endl << "Terminating! because of Error " << retval << endl;
  exit(retval);
}

bool TRANS_INFOsortfunchrstartpos(struct TRANS_INFO ti1, struct TRANS_INFO ti2){
  return (ti1.chrStart < ti2.chrStart);
}
bool GENE_INFOsortfunchrstartpos(struct GENE_INFO g1, struct GENE_INFO g2){
  return (g1.chrStart < g2.chrStart);
}

int load_havana_transcripts(vector <TRANS_LIST> &havanaTranscripts, vector<GENES_LIST>&havanaGenes)
{
    for (unsigned c=0;c<MITOCHONDRION;++c){//X,Y,M chromosomes
      TRANS_LIST transListEmpty;
      GENES_LIST genesListEmpty;
      transListEmpty.chrNum=c;
      genesListEmpty.chrNum=c;
      havanaTranscripts.push_back(transListEmpty);
      havanaGenes.push_back(genesListEmpty);
    }
    ifstream havanaGeneFile(geneFileName.c_str());
    if (checkFile(geneFileName)!=1){
      cerr << "HAVANA gene file not found" << geneFileName;
      terminate(3);
    }
    while (!havanaGeneFile.eof()){
      string line="";
      getline(havanaGeneFile,line);
      unsigned int columns=0;
      size_t tab=0;
      string s_chrNum="", s_HAVANA="", s_type="", s_chrStart="", s_chrEnd="", s_field1="", s_WC="", s_field2="", s_info="";
      do{
	tab =  line.find_first_of('\t');
	columns++;
	switch (columns){
	  case 1: s_chrNum = line.substr(0, tab);
	  break;
	  case 2: s_HAVANA = line.substr(0, tab);
	  break;
	  case 3: s_type = line.substr(0, tab);
	  break;
	  case 4: s_chrStart = line.substr(0, tab);
	  break;
	  case 5: s_chrEnd = line.substr(0, tab);
	  break;
	  case 6: s_field1 = line.substr(0, tab);
	  break;
	  case 7: s_WC = line.substr(0, tab);
	  break;
	  case 8: s_field2 = line.substr(0, tab);
	  break;
	  case 9: s_info = line.substr(0, tab);
	  break;
	  default:
	    break;
	}
	line = line.substr(tab+1, line.size());
      }while(tab!=ULONG_MAX);
      /*    cout << endl << columns;*/
      if (s_type=="transcript"){
	unsigned int chrStart=0, chrEnd=0;
	stringstream ss_chrStart(s_chrStart),ss_chrEnd(s_chrEnd);
	bool WC=0;
	if (s_WC=="+"){
/*	  cout << endl << s_chrNum <<"\t"<< s_chrStart <<"\t"<<s_chrEnd<<"\t"<<"W/+";*/
	  ss_chrStart>>chrStart;
	  ss_chrEnd>>chrEnd;
	  WC=1;
	}
	else if (s_WC=="-"){
/*	  cout << endl << s_chrNum <<"\t"<< s_chrEnd<<"\t"<< s_chrStart<<"\t"<<"C/-";*/
	  ss_chrStart>>chrStart;
	  ss_chrEnd>>chrEnd;
	  WC=0;
	}
	else{
	  cerr <<endl<< "Cannot determine sense / anti-sense strand information for transcript "<< s_HAVANA;
	}
	stringstream ss_info(s_info);
	string gene_id="";
	string gene_type="";
	string gene_status="";
	string gene_name="";
	string transcript_type="";
	string transcript_status="";
	string transcript_name="";
	do{
	  string infoType="";
	  ss_info >> infoType;
	  if (infoType=="gene_id"){
	    ss_info >> gene_id;
	    /*	  cout << endl << gene_id;*/
	  }
	  if (infoType=="gene_type"){
	    ss_info >> gene_type;
	    /*	cout << endl << gene_type;*/
	  }
	  if (infoType=="gene_status"){
	    ss_info >> gene_status;
	    /*	cout << endl << gene_status;*/
	  }
	  if (infoType=="gene_name"){
	    ss_info >> gene_name;
	    //remove enclosing quotes and ;
	    if (gene_name.find_first_of("\"")!=string::npos){
	      gene_name=gene_name.substr(gene_name.find_first_of("\"")+1);
	    }
	    if (gene_name.find_last_of("\"")!=string::npos){
	      gene_name=gene_name.substr(0,gene_name.find_last_of("\""));
	    }
	    /*	cout << endl << gene_name;*/
	  }
	  if (infoType=="transcript_type"){
	    ss_info >> transcript_type;
	    /*	cout << endl << transcript_type;*/
	  }
	  if (infoType=="transcript_status"){
	    ss_info >> transcript_status;
	    /*	cout << endl << transcript_status;*/
	  }
	  if (infoType=="transcript_name"){
	    ss_info >> transcript_name;
	    /*cout << endl << transcript_name;*/
	  }
      }while(ss_info.good());
      if(gene_type=="\"protein_coding\";" && \
	gene_status=="\"KNOWN\";" && \
	transcript_type=="\"protein_coding\";" && \
	transcript_status=="\"KNOWN\";" )
/*	cout << endl << gene_id << "\t" << gene_name<<"\t"<<s_WC;/*WAITUSER*/
	if (extract_chrnum(s_chrNum,1)>0){
	  havanaTranscripts[extract_chrnum(s_chrNum,1)].proteinCodingGenes.push_back({chrStart,chrEnd,gene_name,WC,transcript_name});
	}
	/*WAITUSER*/;
    }
  }
  for (unsigned c=0;c<MITOCHONDRION;++c){
    if( havanaTranscripts[c].proteinCodingGenes.size()){
      sort(havanaTranscripts[c].proteinCodingGenes.begin(),havanaTranscripts[c].proteinCodingGenes.end(),TRANS_INFOsortfunchrstartpos);
  /*    cout << endl << "chr" << convert_chrnum_to_string(havanaTranscripts[c].chrNum) << "\t" << havanaTranscripts[c].proteinCodingGenes.size() << " protein_coding locations, ";*/
      vector<string> geneNames;
      map<string,unsigned int> geneStart;
      map<string,unsigned int> geneEnd;
      map<string,bool> geneWC;
      for (vector<TRANS_INFO>::iterator ig= havanaTranscripts[c].proteinCodingGenes.begin();ig!=havanaTranscripts[c].proteinCodingGenes.end();++ig){
	  string geneName=(*ig).geneName;
	  geneNames.push_back((*ig).geneName);
	  if(geneStart.find(geneName)==geneStart.end()){
	    geneStart[geneName]=(*ig).chrStart;
/*	    cerr<<endl<<"adding "<<geneName<<" chrstart "<<(*ig).chrStart;WAITUSER*/
	  }
	  else{
	    if((int)geneStart[geneName]>(int)(*ig).chrStart){
/*	      cerr<<endl<<"adjusting "<<geneName<<" chrstart from "<<geneStart[geneName]<<" to "<<(*ig).chrStart;*/
	      map<string,unsigned int>::iterator c=geneStart.find(geneName);geneStart.erase(c);
	      geneStart[geneName]=(*ig).chrStart;
/*	      cerr<<endl<<" new chrstart "<<geneStart[geneName];WAITUSER;*/
	    }
	  }
	  if(geneEnd.find(geneName)==geneEnd.end()){
	    geneEnd[geneName]=(*ig).chrEnd;
// 	    cerr<<endl<<"adding "<<geneName<<" chrend "<<(*ig).chrEnd;WAITUSER

	  }
	  else{
	    if((int)geneEnd[geneName]<(int)(*ig).chrEnd){
/*	      cerr<<endl<<(int)geneEnd[geneName]-(int)(*ig).chrEnd;*/
/*      	cerr<<endl<<"adjusting "<<geneName<<" chrend from "<<geneEnd[geneName]<<" to "<<(*ig).chrEnd;*/
      	      map<string,unsigned int>::iterator c=geneEnd.find(geneName);geneEnd.erase(c);
	      geneEnd[geneName]=(*ig).chrEnd;
/*	      cerr<<endl<<" new chrend "<<geneEnd[geneName];WAITUSER;*/
	    }
	  }
	  if(geneWC.find(geneName)==geneWC.end()){
	    geneWC[geneName]=(*ig).WC;
	  }
      }
      sort(geneNames.begin(),geneNames.end());
      vector<string>::iterator ign=unique(geneNames.begin(),geneNames.end());
      unsigned int geneCount=0;
      for(vector<string>::iterator i=geneNames.begin();i!=ign;++i,++geneCount){
	  havanaGenes[c].proteinCodingGenes.push_back({geneStart[(*i)],geneEnd[(*i)],(*i),geneWC[(*i)]});
/*	  cerr<<endl<<(*i)<<"\t"<<geneStart[(*i)]<<"\t"<<geneEnd[(*i)];WAITUSER*/
      }
      sort(havanaGenes[c].proteinCodingGenes.begin(),havanaGenes[c].proteinCodingGenes.end(),GENE_INFOsortfunchrstartpos);
     // cerr << "Chr" << convert_chrnum_to_string(c) << "\t" << geneCount << " Unique Gene Names; "<<endl;
    }
  }
  return 1;
}

bool sortSeqReadsFun (struct SEQUENCE_READS s1, struct SEQUENCE_READS s2)
{
  return (s1.chrPos < s2.chrPos);
}

int getSequenceReads(string Dir, vector<SEQUENCE_READS> &sequenceReads,unsigned int chrNum){
  if (checkFile(Dir+"/chr"+convert_chrnum_to_string(chrNum)+"+.hits.txt")!=1){ cerr << Dir+"/chr"+convert_chrnum_to_string(chrNum)+"+.hits.txt"; terminate(chrNum);}
  if (checkFile(Dir+"/chr"+convert_chrnum_to_string(chrNum)+"-.hits.txt")!=1){ cerr << Dir+"/chr"+convert_chrnum_to_string(chrNum)+"-.hits.txt"; terminate(chrNum);}
  ifstream chrFileW;
  chrFileW.open((Dir+"/chr"+convert_chrnum_to_string(chrNum)+"+.hits.txt").c_str());
  ifstream chrFileC;
  chrFileC.open((Dir+"/chr"+convert_chrnum_to_string(chrNum)+"-.hits.txt").c_str());
  vector <SEQUENCE_READS> reads;
  while (!chrFileW.eof()){
    string line="";
    getline(chrFileW,line);
    stringstream ss(line);
    SEQUENCE_READS tmp;
    ss >> tmp.hits >> tmp.chrPos;
    reads.push_back(tmp);
  }
  while (!chrFileC.eof()){
    string line="";
    getline(chrFileC,line);
    stringstream ss(line);
    SEQUENCE_READS tmp;
    ss >> tmp.hits >> tmp.chrPos;
    reads.push_back(tmp);
  }
  sort(reads.begin(),reads.end(),sortSeqReadsFun);
// for (vector <SEQUENCE_READS>::iterator i=reads.begin();i<reads.end();++i)
//     cout << endl << (*i).chrPos;
//   WAITUSER;
  sequenceReads=reads;
  return 0;
}

double hgcalc_gte(unsigned int ps/*pop. size*/, unsigned int sa/*sample size*/,unsigned int sp/*Success Pop.*/ \
,unsigned int ss/*Success Sample*/){
  double pval=1.0;
  if (ss>=1&&ps>=sa&&ps>=sp&&sa>=ss){
     pval=gsl_cdf_hypergeometric_Q(ss-1,sp,ps-sp,sa);
  }
  return pval;
}

int store_havana_genes(vector <GENES_LIST> &havanaGenes){
  for (unsigned c=0;c<MITOCHONDRION;++c){
    if(havanaGenes[c].proteinCodingGenes.size()){
	for(vector<GENE_INFO>::iterator g=havanaGenes[c].proteinCodingGenes.begin();g!=havanaGenes[c].proteinCodingGenes.end();++g){
	  cout<<endl<<(*g).geneName<<"\t"<<(*g).chrStart<<"\t"<<(*g).chrEnd;
	}
    }
  }
    return 1;
}

int getMappabilityMap(string chrNumFileName, vector <MAPPABILITY_DATA> &mappabilityMapList){
  #define READSIZE "45"
  ifstream controlChrFile(chrNumFileName.c_str());
  unsigned int mappableBases=0;
  vector<unsigned>chrNumList;
  while (!controlChrFile.eof()){
    string line="";
    getline (controlChrFile,line);
    string::size_type tab_location;
    tab_location=line.find_first_of('\t');
    unsigned int chrNum = extract_chrnum(line.substr(0,tab_location),true);
    if(chrNum!=0)chrNumList.push_back(chrNum);
  }
/*  omp_set_num_threads(20);
 #pragma omp parallel
  {
  #pragma omp for*/
  for(unsigned c=0;c<chrNumList.size();++c)
  {
    unsigned chrNum=chrNumList[c];
    if (chrNum!=0){
      string mapFileName=mapDir+"map_chr"+convert_chrnum_to_string2(chrNum)+"_"+"45"+".txt";
      //cout << endl << mapFileName; //WAITUSER;
      if (checkFile(mapFileName)!=1){
	cout << endl << "Cannot open " << mapFileName; WAITUSER;
	terminate(chrNum);
      }
      MAPPABILITY_DATA mapDataTmp;
      boost::iostreams::stream_buffer<boost::iostreams::file_source> mapFileSource(mapFileName.c_str());
      istream mapFile(&mapFileSource);
      //ifstream mapFile(mapFileName.c_str());
      unsigned int chrSize=0;
      stringstream buffer;
      buffer <<  mapFile.rdbuf();
      string content(buffer.str());
/*      cout << endl << content.size();*/
      for (unsigned int n=0;n!=content.size();n+=2){
	bool mapVal=0;
/*	cout << endl << content[n];*/
	if (content[n]=='2'){
	  mapVal=0;
	}
	else if (content[n]=='1'){
	  mapVal=1;
	  mappableBases++;
	}
	else{
	  cerr << endl << "Warning nonstandard mapvalue of " << content[n] << " Assuming non mappable!";
	}
	mapDataTmp.mappabilityMap.push_back(mapVal);
	++chrSize;
      }
      mapDataTmp.chrNum=chrNum;
      mapDataTmp.chrSize=chrSize;
      mapDataTmp.readSize=45;
//       pthread_mutex_lock(&mutex_output);
      mappabilityMapList.push_back(mapDataTmp);
//      cerr << endl << "Chromosome " << chrNum << " Size " << chrSize;
//       pthread_mutex_unlock(&mutex_output);
    }
  }
//   }
 // cerr<<endl<<"Total mappable bases = "<<mappableBases;
  return mappableBases;
}

int calcHypergeometricPval(unsigned int chrNum,string chrReadsFileName,string Dir1,string Dir2, \
vector<WINDOW_DATA> &outData, vector<GENES_LIST>&havanaGenes)
{
      unsigned int numWindows=0;
      vector <CHR_READS> ChrList1, ChrList2;
      //cerr<<endl<<"Total Reads in data1 = "<<getChrReads(Dir1+chrReadsFileName,ChrList1);
      getChrReads(Dir1+chrReadsFileName,ChrList1);
      //cerr<<endl<<"Total Reads in data2 = "<<getChrReads(Dir2+chrReadsFileName,ChrList2);
      getChrReads(Dir2+chrReadsFileName,ChrList2);
      unsigned int currentChrNum=chrNum;
      //cerr<<endl<<"Chr"<<chrNum;
      unsigned int Reads1=0;
      for (vector <CHR_READS>::iterator iC1=ChrList1.begin();iC1!=ChrList1.end();++iC1){
	  if ((*iC1).chrNum==currentChrNum)
	  {
	    Reads1=(*iC1).reads;
	  }
      }
      unsigned int Reads2=0;
      for (vector <CHR_READS>::iterator iC2=ChrList2.begin();iC2!=ChrList2.end();++iC2){
	  if ((*iC2).chrNum==currentChrNum)
	  {
	    Reads2=(*iC2).reads;
	  }
      }
      vector <SEQUENCE_READS> SequenceReads1, SequenceReads2;
      getSequenceReads(Dir1,SequenceReads1,currentChrNum);
      getSequenceReads(Dir2,SequenceReads2,currentChrNum);
      vector <SEQUENCE_READS>::iterator iControlStart=SequenceReads1.begin();
      vector <SEQUENCE_READS>::iterator iExpStart=SequenceReads2.begin();
   if(havanaGenes[chrNum].proteinCodingGenes.size()){
     for(vector<GENE_INFO>::iterator g=havanaGenes[chrNum].proteinCodingGenes.begin();g!=havanaGenes[chrNum].proteinCodingGenes.end();++g){
       unsigned int startPos=(*g).chrStart-1;//calibrate for bowtie 0 beginning
       unsigned int endPos=(*g).chrEnd-1;
       string geneName=(*g).geneName;
       bool WC=(*g).WC;
/*       cerr<<endl<<"Chr"<<convert_chrnum_to_string(chrNum)<<"\t"<<geneName<<"\t"<<WC<<"\t"<<startPos<<"\t"<<endPos<<"\t"<<endPos-startPos<<"\t"<<Reads1<<"\t"<<Reads2;WAITUSER*/
       unsigned int windowReads1=0;
       unsigned int windowReads2=0;
       unsigned int windowStart=startPos;
       unsigned int windowEnd=endPos;
       {//window1 reads
		bool hitsFound=0;
		bool firstHitFound=0;
		for (vector <SEQUENCE_READS>::iterator iC=iControlStart; iC!=SequenceReads1.end(); ++iC)
		{//find all reads in the current window
		    if (((*iC).chrPos>=windowStart) && ((*iC).chrPos<=windowEnd))//
		    {
		      if(firstHitFound==0){
			firstHitFound=1;
			iControlStart=iC;
		      }
		      hitsFound=1;
		      windowReads1+=(*iC).hits;
		    }
		    if ((*iC).chrPos > windowEnd) break;//
		}
		//cout << endl << windowStart << "\t"  << windowEnd-1 << "\t"<<windowReads1;
		if (hitsFound==0){
		}
	}
	{//window2 reads
		bool hitsFound=0;
		bool firstHitFound=0;
		for (vector <SEQUENCE_READS>::iterator iC=iExpStart; iC!=SequenceReads2.end(); ++iC)
		{
		    if (((*iC).chrPos>=windowStart) && ((*iC).chrPos<windowEnd))
		    {
      		      if(firstHitFound==0){
			firstHitFound=1;
			iExpStart=iC;
		      }
		      hitsFound=1;
		      windowReads2+=(*iC).hits;
		    }
		    if ((*iC).chrPos > windowEnd) break;//
		}
		//cout << "\t" << windowStart << "\t"  << windowEnd-1 << "\t" << windowReads2;
		if (hitsFound==0){
		}
	 }
	 if (windowReads1>=1 && windowReads2>=0){
	      numWindows++;
	      unsigned int ps=Reads1+Reads2;/*Pop. Size*/
	      unsigned int sa=windowReads1+windowReads2;/*Sample Size*/
	      unsigned int sp=Reads1;/*Success Population*/
	      unsigned int ss=windowReads1;/*Success Sample*/
// 	      double pval= gsl_cdf_hypergeometric_Q(windowReads1-1,Reads1,Reads2,windowReads2+windowReads1);
	      double pval=hgcalc_gte(ps,sa,sp,ss);
/*	      cerr<<endl<<"Chr"<<convert_chrnum_to_string(chrNum)<<"\t"<<geneName<<"\t"<<WC<<"\t"<<startPos<<"\t"<<endPos<<"\t"<<endPos-startPos;
	      cerr<<endl<<windowReads1<<"\t"<<windowReads2<<"\t"<<Reads1<<"\t"<<Reads2<<"\t"<<pval;WAITUSER*/
     	      outData.push_back({geneName,currentChrNum,windowReads1,windowReads2,windowStart,windowEnd,pval});

	 }
	 //avoid holes in the data list, pval=2.0 for filtering later
	 else{
      	      outData.push_back({geneName,currentChrNum,windowReads1,windowReads1,windowStart,windowEnd,2.0,1.0});
	 }

     }
   }
}

bool SortOutDataPvalFun (struct WINDOW_DATA s1, struct WINDOW_DATA s2){
  return (s1.pval<s2.pval);
}

bool SortOutDataWindowStartFun (struct WINDOW_DATA s1, struct WINDOW_DATA s2){
  return (s1.windowStart<s2.windowStart);
}

bool SortOutDataWindowGeneName (struct WINDOW_DATA s1, struct WINDOW_DATA s2){
  return (s1.geneName<s2.geneName);
}

bool SortOutDataChrNumFun (struct WINDOW_DATA s1, struct WINDOW_DATA s2){
  return (s1.chrNum<s2.chrNum);
}


unsigned int bh(vector<double>&pvalList,vector<double>&qValList)
{
      unsigned int count=0;
      double previous_bhVal=0.0;
      unsigned listSize=pvalList.size();
      for(vector<double>::iterator p=pvalList.begin();p!=pvalList.end();++p,++count){
	#define DEBUGPVAL
	#ifdef DEBUGPVAL
	  if ((*p)>1.0 || (*p)<0.0){
	    cerr<<endl<<(*p)<<" bad pval!";
	  }
	#endif
	double bhVal=(*p)*listSize/(count+1);
	if(bhVal>1.0){
	  bhVal=1.0;
	}
	if(bhVal<previous_bhVal){
	  bhVal=previous_bhVal;
	}
	previous_bhVal=bhVal;
	qValList.push_back(bhVal);
      }
      return(qValList.size());
}

unsigned int bonferroni(vector<double>&pvalList,vector<double>&qValList)
{
      unsigned listSize=pvalList.size();
      for(vector<double>::iterator p=pvalList.begin();p!=pvalList.end();++p){
	#define DEBUGPVAL
	#ifdef DEBUGPVAL
	  if ((*p)>1.0 || (*p)<0.0){
	    cerr<<endl<<(*p)<<" bad pval!";
	  }
	#endif
	double bonferroniVal=(*p)*listSize;
	if(bonferroniVal>1.0){
	  bonferroniVal=1.0;
	}
	qValList.push_back(bonferroniVal);
      }
      return(qValList.size());
}

unsigned int getMappable(unsigned int startChrPos, unsigned int endChrPos, vector<bool>&mappabilityMap){
  unsigned int mappableCount=0;
  if (startChrPos>=mappabilityMap.size()) return 0;
   for (unsigned int chrPos=startChrPos;(chrPos<=endChrPos) && (chrPos < mappabilityMap.size());++chrPos){
      if (mappabilityMap[chrPos]==1){
	++mappableCount;
      }
    }
    return mappableCount;
}





