//This software is part of iSeq suite (breakome.eu)
//Hygestat_genes Version : 1.0

#include <hygestat.hpp>
int main (int argc, char**argv){
    string chrReadsFileName ="chrReads.txt";
    int argcNum=1;
    string argshelp="usage:> hygestat_genes <sequenced_data_directory_1> <sequenced_data_directory_2> <mappability directory> <gtf genes file name>";
    string dir1="./";
    if (argc <= argcNum){
      cout << endl <<argshelp;
      cout << endl << "Please Input sequenced data directory signal (treated sample): ";
      cin >> dir1;
    }
    else{
      dir1=argv[argcNum++];
    }
    if(checkFile(dir1+chrReadsFileName)!=1){cout << endl << dir1+chrReadsFileName;terminate(2);}
    string dir2="./";
    if (argc <= argcNum){
      cout << endl << argshelp;
      cout << endl << "Please Input sequenced data directory control (non treated sample): ";
      cin >> dir2;
    }
    else
      dir2=argv[argcNum++];
    if (checkFile(dir2+chrReadsFileName)!=1){cout << endl << dir2+chrReadsFileName;terminate(4);}

    if (argc <= argcNum){
      cout << endl << argshelp;
      cout << endl << "Please Input mappable regions data directory (mappability): ";
      cin >> mapDir;
    }
    else
      mapDir=argv[argcNum++];

    if (argc <= argcNum){
      cout << endl << argshelp;
      cout << endl << "Please Input gtf gene file (file containing genes features): ";
      cin >> geneFileName;
    }
    else
      geneFileName=argv[argcNum++];
    if (checkFile(geneFileName)!=1){cout << endl << geneFileName;terminate(5);}

    bool annot=false;
    string cancerGeneFileName="";
    if (argc <= argcNum){
      //cout << endl << "Annotations disabled";
    }
    else{
      annot=true;
      cancerGeneFileName=argv[argcNum++];
    }
    ofstream out("output.txt");
    vector <TRANS_LIST> havanaTranscripts;
    vector<GENES_LIST> havanaGenes;
    load_havana_transcripts(havanaTranscripts,havanaGenes);
//     store_havana_genes(havanaGenes);
    vector<WINDOW_DATA>outData;
    {
	vector <CHR_READS> ChrList1, ChrList2;
	getChrReads(dir1+chrReadsFileName,ChrList1);
	getChrReads(dir2+chrReadsFileName,ChrList2);
	if (ChrList1.size()!=ChrList2.size()){
	  cerr << endl << ChrList1.size() << "  " << ChrList2.size() << " Chromosome size mismatch"; WAITUSER;
	}
	for(vector<CHR_READS>::iterator c=ChrList1.begin();c!=ChrList1.end();++c){
	  calcHypergeometricPval((*c).chrNum,chrReadsFileName,dir1,dir2,outData,havanaGenes);
	}
    }
    sort(outData.begin(),outData.end(),SortOutDataPvalFun);
    vector<double> pvalList;
    for(vector<WINDOW_DATA>::iterator iw=outData.begin();iw!=outData.end();++iw){
      if((*iw).pval<2.0){
	  pvalList.push_back((*iw).pval);
      }
    }
    vector<double>qValList;
    vector<double>qValList2;
    bh(pvalList,qValList);
    bonferroni(pvalList,qValList2);
    if(pvalList.size()!=qValList.size()){
	cerr<<endl<<"Oops BH procedure failed!";
	terminate(10);
    }
    if(pvalList.size()!=qValList2.size()){
	cerr<<endl<<"Oops Bonferroni procedure failed!";
	terminate(11);
    }

    vector<WINDOW_DATA>::iterator iw=outData.begin();
    vector<double>::iterator q=qValList.begin();
    for(;iw!=outData.end(),q!=qValList.end();++iw,++q){
      (*iw).qval=(*q);
    }
    iw=outData.begin();
    vector<double>::iterator q2=qValList2.begin();
    for(;iw!=outData.end(),q2!=qValList2.end();++iw,++q2){
      (*iw).qval2=(*q2);
    }
    sort(outData.begin(),outData.end(),SortOutDataChrNumFun);
    stable_sort(outData.begin(),outData.end(),SortOutDataWindowGeneName);
    iw=outData.begin();
    cout.precision(10);
    vector <MAPPABILITY_DATA> mappabilityMapList;
    unsigned int mappableBases=getMappabilityMap(dir1+chrReadsFileName, mappabilityMapList);
    cout<<"                     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n";
    cout<<"                     $$$                                                                                                                 $$$\n";
    cout<<"                     $$$ Thanks for using Hygestat genes from Rowicka lab (UTMB Health Galveston). Check the results in output.txt file! $$$\n";
    cout<<"                     $$$                                                                                                                 $$$\n";
    cout<<"                     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"<<endl;
    for(;iw!=outData.end();++iw){
     /* if(((*iw).pval)<2.0)*/{
        vector<bool> mappabilityMap;
	for (vector<MAPPABILITY_DATA>::iterator iM=mappabilityMapList.begin();iM!=mappabilityMapList.end();++iM){
	    if ((*iM).chrNum==(*iw).chrNum){
	      mappabilityMap = (*iM).mappabilityMap;
	    }
	}
	out<<"chr"<<convert_chrnum_to_string((*iw).chrNum)<<"\t"<<(*iw).geneName<<"\t"<<(*iw).windowStart<<"\t"<<(*iw).windowEnd<<"\t"<<(*iw).windowEnd-(*iw).windowStart+1<<"\t" \
	<<getMappable((*iw).windowStart,(*iw).windowEnd,mappabilityMap)<<"\t"<<(*iw).windowReads1<<"\t"<<(*iw).windowReads2<<"\t"<<(*iw).pval<<"\t"<<(*iw).qval<<endl;
      }
    }
}


